export const charactersList = [
  "Avengers",
  "Marvel",
  "My Hero",
  "Transformers",
  "Spiderman",
  "Jurassic",
  "Game of Thrones",
  "The Flash",
  "Batman",
];
export const categoriesList = [
  "Accessories",
  "Action-figures",
  "Statue",
  "Collectibles",
  "T-shirt",
];
export const priceRangesList = [
  "0-999",
  "1000-9999",
  "10000-99999",
  "above 100000",
];
export const profilePageList = [
  "Order History",
  "Favourite",
  "Account Details",
  "Payment Methods",
  "My Addresses",
];
