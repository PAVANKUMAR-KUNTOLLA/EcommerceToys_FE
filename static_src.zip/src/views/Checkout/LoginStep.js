import React, { Component } from "react";

const LoginStep = () => {
  return <h1>Login Step</h1>;
};

export default LoginStep;
