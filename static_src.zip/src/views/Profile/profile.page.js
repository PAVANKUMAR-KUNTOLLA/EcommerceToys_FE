import React, { useState, useEffect } from "react";
import Page from "../../components/Page";
import {
  Box,
  Container,
  Grid,
  Avatar,
  Typography,
  TextField,
  useMediaQuery,
  Button,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import Card from "@mui/material";

import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import { profilePageList } from "../../constants";

import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const customProfileStyles = makeStyles((theme) => ({
  MainBlock: {
    display: "flex",
    marginTop: "50px",
    flexDirection: "column",
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      flexDirection: "row",
    },
  },
  Account: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    maxWidth: "50%",
    justifyContent: "space-between",
    marginLeft: "auto",
    marginRight: "auto",
    [theme.breakpoints.down("sm")]: {
      maxWidth: "80%",
      marginBottom: "10px",
    },
  },
}));

const ProfilePage = () => {
  const customStyles = customProfileStyles();

  const [details, setAddress] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAddress((prevAddress) => ({
      ...prevAddress,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can perform any additional logic or submit the form data here
    console.log("Form Data:", address);
  };

  function createData(name, calories, fat, carbs, protein) {
    return { name, calories, fat, carbs, protein };
  }

  const rows = [
    createData("Frozen yoghurt", 159, 6.0, 24, 4.0),
    createData("Ice cream sandwich", 237, 9.0, 37, 4.3),
    createData("Eclair", 262, 16.0, 24, 6.0),
    createData("Cupcake", 305, 3.7, 67, 4.3),
    createData("Gingerbread", 356, 16.0, 49, 3.9),
  ];

  return (
    <Page title="Profile">
      <Grid
        maxWidth="lg"
        sx={{
          marginBottom: "50px",
          justifyContent: "space-between",
          marginLeft: "auto",
          marginRight: "auto",
        }}
      >
        <Typography
          variant="h3"
          sx={{ marginBottom: "30px", marginTop: "20px", marginLeft: "10px" }}
        >
          Account Details
        </Typography>
        <hr></hr>
      </Grid>
      <Container maxWidth="lg" className={customStyles.MainBlock}>
        <Container maxWidth="sm">
          <form onSubmit={handleSubmit}>
            <Box className={customStyles.Account}>
              <Grid display={"flex"}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="icon icon-tabler icon-tabler-user-circle"
                  width="64"
                  height="64"
                  viewBox="0 0 24 24"
                  strokeWidth="1.5"
                  stroke="#2c3e50"
                  fill="none"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                  <path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" />
                  <path d="M12 10m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                  <path d="M6.168 18.849a4 4 0 0 1 3.832 -2.849h4a4 4 0 0 1 3.834 2.855" />
                </svg>
                <Typography
                  variant="h3"
                  sx={{
                    marginLeft: "20px",
                    alignContent: "center",
                    marginTop: "auto",
                    marginBottom: "auto",
                  }}
                >
                  Profile
                </Typography>
              </Grid>
              <TextField
                id="name"
                name="name"
                label="Name"
                variant="outlined"
                value={details.name}
                onChange={handleChange}
                required
              />
              <TextField
                id="email"
                name="email"
                label="Email"
                variant="outlined"
                value={details.email}
                onChange={handleChange}
                required
              />
              <TextField
                id="password"
                name="password"
                label="password"
                variant="outlined"
                value={details.password}
                onChange={handleChange}
                required
              />
              <TextField
                id="ConfirmPassword"
                name="pasword"
                label="Confirm Password"
                variant="outlined"
                value={details.confirmPassword}
                onChange={handleChange}
                required
              />
              <Button
                color="primary"
                fullWidth
                size="large"
                type="submit"
                variant="contained"
              >
                Reset
              </Button>
            </Box>
          </form>
        </Container>
        <Container maxWidth="sm" className={customStyles.Orders}>
          <Typography variant="h3" sx={{ marginTop: "10px" }}>
            Ordered Items
          </Typography>
          <TableContainer component={Paper} sx={{ marginTop: "35px" }}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell align="right">Quantity</TableCell>
                  <TableCell align="right">Price</TableCell>
                  <TableCell align="right">Status</TableCell>
                  <TableCell align="right">Orderd</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row) => (
                  <TableRow
                    key={row.name}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {row.name}
                    </TableCell>
                    <TableCell align="right">{row.calories}</TableCell>
                    <TableCell align="right">{row.fat}</TableCell>
                    <TableCell align="right">{row.carbs}</TableCell>
                    <TableCell align="right">{row.protein}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Container>
      </Container>
    </Page>
  );
};

export default ProfilePage;
