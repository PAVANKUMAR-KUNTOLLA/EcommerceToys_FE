import React, { useState, useEffect } from "react";
import Page from "../../components/Page";
import ProductCard from "../../components/card";
import CategoriesCard from "../../components/categoryCard";
import ProductSlider from "../../components/slider";
import {
  Box,
  Container,
  Grid,
  Typography,
  CircularProgress,
} from "@mui/material";
import { makeStyles } from "@mui/styles";

import Api from "../../components/Api";
import { privateApiGET } from "../../components/PrivateRoute";
import { useDispatch, useSelector } from "react-redux";
import {
  setProducts,
  setLoadingSpin,
  setSearch,
} from "../../redux/products/produtsSlice";
import LoadingSpin from "../../components/LoadingSpin";
import DataNotFound from "../../components/DataNotFound";
import MyFooter from "./Footer";
import AdverstiesmentImagesSlider from "../../components/advertisement";
export const useStyles = makeStyles((theme) => ({
  container: {
    [theme.breakpoints.up("lg")]: {
      maxWidth: theme.breakpoints.values.lg,
    },
    [theme.breakpoints.down("md")]: {
      maxWidth: theme.breakpoints.values.sm,
    },
    Typography: {},
  },
}));

const HomePage = () => {
  const customStyles = useStyles();

  const products = useSelector((state) => state.products.products);
  const favourites = useSelector((state) => state.products.favourites);
  const isLoadingSpin = useSelector((state) => state.products.isLoadingSpin);
  // const latest = useSelector((state) => state.products.latest);
  const dispatch = useDispatch();
  const searchQuery = useSelector((state) => state.products.searchQuery);
  const isSearchOn = useSelector((state) => state.products.isSearchOn);

  const selectedCategories = new Set();

  const categoriesItems = products
    ? products.filter((item) => {
        if (
          !selectedCategories.has(item.category) &&
          item.category != "accessories"
        ) {
          selectedCategories.add(item.category);
          return true;
        }
        return false;
      })
    : [];

  const handleFetchProducts = () => {
    dispatch(setLoadingSpin(true));
    privateApiGET(Api.products)
      .then((response) => {
        const { status, data } = response;
        if (status === 200) {
          console.log("data", data);
          dispatch(setProducts(data?.data));
          dispatch(setLoadingSpin(false));
        }
      })
      .catch((error) => {
        console.log("Error", error);
        dispatch(setLoadingSpin(false));
      });
  };

  useEffect(() => {
    handleFetchProducts();
    dispatch(setSearch(false));
  }, []);

  return (
    <Page title="home">
      <AdverstiesmentImagesSlider />
      {!isLoadingSpin ? (
        <Container maxWidth="md" className={customStyles.container}>
          <Grid
            container
            spacing={2}
            mt={3}
            sx={{ display: isSearchOn ? "none" : "flex" }}
          >
            <Grid item xs={12}>
              <Typography
                variant="h1"
                sx={{
                  alignItems: "center",
                  marginTop: "50px",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              >
                Your favourite products
              </Typography>
              <hr
                sx={{
                  borderTop: "2px solid black",
                  fontWeight: "bold",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              ></hr>
            </Grid>
            {favourites.map((product) => (
              <Grid item key={product.id} xs={6} md={3} lg={3}>
                <ProductCard product={product} />
              </Grid>
            ))}
          </Grid>
          <Grid
            container
            spacing={2}
            mt={2}
            sx={{ display: isSearchOn ? "none" : "flex" }}
          >
            <Grid item xs={12}>
              <Typography
                variant="h1"
                sx={{
                  alignItems: "center",
                  marginTop: "50px",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              >
                Categories
              </Typography>
              <hr
                sx={{
                  borderTop: "2px solid black",
                  fontWeight: "bold",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              ></hr>
            </Grid>
            <Grid
              container
              spacing={2}
              mt={2}
              sx={{ display: isSearchOn ? "none" : "flex" }}
            >
              {categoriesItems.map((product) => (
                <Grid item key={product.id} xs={6} md={3} lg={3}>
                  <CategoriesCard product={product} />
                </Grid>
              ))}
            </Grid>
          </Grid>

          <Grid
            container
            spacing={2}
            mt={3}
            sx={{ display: isSearchOn ? "none" : "flex" }}
          >
            <Grid item xs={12}>
              <Typography
                variant="h1"
                sx={{
                  alignItems: "center",
                  marginTop: "50px",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              >
                Products you may like
              </Typography>
              <hr
                sx={{
                  borderTop: "2px solid black",
                  fontWeight: "bold",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}
              ></hr>
            </Grid>
            <ProductSlider products={products} />
          </Grid>
          {isSearchOn && products.length > 0 ? (
            <Grid container spacing={2} mt={2}>
              <Grid item xs={12}>
                <Typography
                  variant="h1"
                  sx={{
                    alignItems: "center",
                    marginTop: "50px",
                    marginLeft: "auto",
                    marginRight: "auto",
                    textTransform: "capitalize",
                  }}
                >
                  {searchQuery}
                </Typography>
                <hr
                  sx={{
                    borderTop: "2px solid black",
                    fontWeight: "bold",
                    marginLeft: "auto",
                    marginRight: "auto",
                  }}
                ></hr>
              </Grid>
              {products.map((product) => (
                <Grid item key={product.id} xs={6} md={3} lg={3}>
                  <ProductCard product={product} />
                </Grid>
              ))}
            </Grid>
          ) : isSearchOn && products.length === 0 ? (
            <DataNotFound />
          ) : null}
        </Container>
      ) : isLoadingSpin ? (
        <LoadingSpin isBackdrop={true} />
      ) : null}
      <MyFooter />
    </Page>
  );
};

export default HomePage;
